# Changelog

## 0.1-rc.3 - 2026-09-08

Correct Chen's initial in HINT, identify the inspected Lee arXiv version, restore the Sauer/Sonderegger subtitle, and add verified DOI/venue details. Audit all 12 references against primary sources. No method or workbook changes.

## 0.1-rc.2 - 2026-09-08
- Corrected three reproduced workbook boundary defects and added complementary judgment measures.
- Separated evaluator materials from the answer key and documented prior work and contribution limits.
- Added a controlled-comparison plan. No empirical validation added.


## Documentation between rc.1 and rc.2
- Linked the separate public design system, candidate evaluation checks and an actual documentation consistency correction.
- Preserved v0.1-rc.1 PDFs, workbooks and release assets. No external validation or full applied evaluation is claimed.

## 0.1-rc.1 - 2026-09-08
- Packaged the engineering-handoff profile, evaluator scorecard and spreadsheet calculations.
- Added traceable synthetic requirements, recovery, reference, findings and batch records.
- Added a specification-based fictional artifact and a feasibility kit.
- Separated evaluator metrics from artifact gate eligibility and owner approval.
- Recorded missing data, abstentions, reference uncertainty and scope limits.
- Corrected the NIST relationship: a separate comment was transmitted September 6; the protocol is not represented as an attachment, adoption or endorsement.

This is a release candidate for author review. External review, empirical validation and archival publication are not completed by creating these files.
