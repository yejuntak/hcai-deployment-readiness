"""Generate progressive HTML reading views from versioned method and criterion sources."""
import argparse
import html
import json
import re
import shutil
from pathlib import Path
import markdown
from hcai_readiness.contracts import Assessment
from hcai_readiness.reporting import render_report
from hcai_readiness.guidance import criteria_catalog
from build_research_pages import STYLE

ROOT = Path(__file__).resolve().parents[1]
PREFIX = '/static/research/ai-readiness/rc4-candidate-2/'
PROTOCOL = ROOT / 'protocol/0.1-rc.4-candidate.2'

def page(title, body):
    return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+html.escape(title)+'</title><style>'+STYLE+'\nmain{max-width:980px}p,li{max-width:80ch}td,th{text-align:left;vertical-align:top;border-bottom:1px solid #ccd6df;padding:12px}table{border-collapse:collapse;width:100%;font-size:15px}th{background:#e8eef4}.table-scroll{overflow:auto}table{min-width:540px}details{margin-block:16px}summary{padding:6px 0}li{margin-block:8px}h1{font-size:clamp(32px,5vw,48px)}.reading-nav{display:flex;gap:24px;flex-wrap:wrap;font-size:15px}code{overflow-wrap:anywhere}main>h1{margin-top:32px}@media print{.reading-nav{display:none}table{min-width:0}.table-scroll{overflow:visible}}\n</style></head><body><main><nav class="reading-nav" aria-label="Protocol navigation"><a href="/research/ai-readiness">Review guide</a><a href="'+PREFIX+'START-HERE.html">Start here</a><a href="/research/ai-readiness/updates">Update log</a></nav>'+body+'</main></body></html>'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--site-root',type=Path)
    args = parser.parse_args()
    output = ROOT/'docs/web'
    output.mkdir(exist_ok=True)
    sources = list(PROTOCOL.glob('*.md')) + [ROOT/'docs'/name for name in ('updates.md','agent-tools.md','migration-rc3-to-rc4.md','research-boundary.md')]
    names = {p.name:p.stem+'.html' for p in sources}
    for source in sources:
        text = source.read_text()
        def link(match):
            label, target = match.groups()
            basename = target.rsplit('/',1)[-1]
            if not target.startswith(('https:','http:')) and basename in names:
                target = PREFIX+names[basename]
            elif target.startswith('../../docs/'):
                target = 'https://github.com/yejuntak/hcai-deployment-readiness/blob/codex/readiness-rc4-candidate/docs/'+basename
            return '['+label+']('+target+')'
        text = re.sub(r'\[([^]]+)\]\(([^)]+)\)',link,text)
        body = markdown.markdown(text,extensions=['tables','fenced_code'])
        body = body.replace('<table>','<div class="table-scroll"><table>').replace('</table>','</table></div>')
        (output/(source.stem+'.html')).write_text(page(source.stem,body))
    synthetic = Assessment.model_validate_json((ROOT/'examples/rc4/low-risk-quick.json').read_text())
    sample = render_report(synthetic,'html').replace('<main>','<main><p><strong>PUBLIC SYNTHETIC EXAMPLE — no real participant or pilot.</strong> The private label below describes the report default, not a confidentiality claim about this constructed example.</p><p><a href="/research/ai-readiness">Return to the guide</a></p>')
    (output/'example-report.html').write_text(sample)
    catalogue = criteria_catalog()
    chunks = []
    for principle in catalogue['principles']:
        chunks.append('<details class="research-connection"><summary class="t-title-m">'+html.escape(principle['title'])+'</summary>')
        for c in catalogue['criteria']:
            if c['id'].startswith('HCAI-'+principle['id']+'.'):
                chunks.append('<details class="research-criterion" id="'+c['id']+'"><summary class="t-title-s">'+html.escape(c['id']+' · '+c['title'])+'</summary>')
                for label,key in [('Requirement','requirement'),('How to check','check'),('Meets the intent','pass_example'),('Common failure','failure_example'),('Verification boundary','verification')]:
                    chunks.append('<p class="t-body-m"><strong>'+label+':</strong> '+html.escape(c[key])+'</p>')
                chunks.append('<p class="t-body-s">Decision gate: '+html.escape(c['gate'])+'. No separate certification is issued.</p></details>')
        chunks.append('</details>')
    template=(ROOT/'docs/research-content.gohtml').read_text().replace('<!-- CRITERIA -->','\n'.join(chunks))
    body=template.replace('{{define "research"}}','').replace('{{end}}','')
    for name in ('index.html','docs/index.html'):
        (ROOT/name).write_text(page('Review AI-built workflows before engineering',body))
    if args.site_root:
        target=args.site_root/'static/research/ai-readiness/rc4-candidate-2'
        target.mkdir(parents=True,exist_ok=True)
        for p in output.glob('*.html'):
            shutil.copyfile(p,target/p.name)
        path=args.site_root/'templates/research.gohtml'
        existing=path.read_text()
        preview=existing[existing.index('{{define "research-preview"}}'):]
        path.write_text(template+'\n'+preview)
    print('Generated linked reading views, criteria, synthetic report and shared research page')

if __name__=='__main__':
    main()
