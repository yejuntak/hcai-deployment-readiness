# Prospective 0.3-preview.2 license correction

Align original code, text and metadata with the owner-confirmed Apache-2.0 license. Preserve NOTICE and third-party rights. Advance MCP to 0.3.0rc2 and Skill/contract to 0.3.0-rc.2 without decision-rule changes. Existing releases remain frozen; publication is pending. See docs/licensing.md.

# 0.3-preview.1 / 0.3.0rc1 / 0.3.0-rc.1

- Make decision compression the explicit motivating model: AI-assisted creation can produce implementation before responsible people have externalized the consequential system model. This is a conceptual rationale, not a measured causal claim.
- Add a targeted Engineering Reasoning Deepening lens inside the existing protocol: Decompress -> Model -> Challenge -> Prove -> Decide. It is not a seventh gate, score or recovered model chain-of-thought.
- Require every consequential choice to record whether engineering deepening applies and why. When required, support truth, ownership, state, boundary, contract, failure/recovery and time/ordering system surfaces.
- Add bounded challenge scenarios with explicit condition, claim at risk, invariant, consequence, evidence and evidence level. Conflicted required surfaces or assumptions, or failed challenges, block the artifact route; unassessed surfaces/assumptions/challenges remain insufficient evidence.
- Make assumptions first-class records with stable IDs, supported/conflicted/unassessed status, consequence-if-false, evidence needed, retained evidence and revisit trigger.
- Deepen G3 and G4 without changing the six gates or fifteen stable criterion IDs. Exact-revision fingerprints include the decision context, so changed decision surfaces invalidate stale validation.
- Refine G6 toward the smallest coherent next software slice that can expose an important assumption end to end instead of authorizing broad layer-by-layer generation.
- Advance the CSV transport contract to 2.1.0 with assumptions.csv, decision-surfaces.csv and challenge-scenarios.csv with explicit evidence levels. Keep JSON, CSV, MCP, Skill, examples and reports on the same model.
- Preserve all historical versions, evidence boundaries, independent-evaluation rules and the separation between formative feedback, software regressions and empirical effectiveness.

# 0.2-preview.3 / 0.2.0rc9 / 0.2.0-rc.9

- Connect consequential choices to purpose, alternatives, rationale provenance, tradeoffs, evidence and accountable human decisions.
- Add a stage-bounded Artifact Review for plans, prototypes and code, with optional independent-evaluation eligibility.
- Require machine-readable artifact population; reject mixed or unknown pooled diagnostics.
- Unify CSV template/example contracts, four evidence stages, locking and adjudication fields; add a synthetic runtime-AI specification case.
- Retain unassessed checks, clarify severity/deferred scope and role-overlap N/A rules.
- Remove the optional model integration from current distribution and website. Regenerate portable Skill, MCP schemas, readable pages and PDFs together.
- Preserve historical protocol releases and DOI identity. Practitioner feedback is improvement input, not evidence of effectiveness.

# H.A.R.D. Protocol 0.2: Decision naming revision, September 25, 2026

Human-centered AI Readiness and Decision Protocol. Public Preview. Exact protocol 0.2-preview.2; MCP 0.2.0rc8; Skill/contract 0.2.0-rc.8.

## Why the name changed

The public display now uses H.A.R.D. to read as initials rather than the adjective hard. The full name retains Readiness and Decision; the review is broader than a visual-design test.

The author found Deployment too technical and easy to mistake for a release-approval claim. Decision describes the actual purpose: decide whether to invest in building a bounded workflow, revise it, or gather missing evidence. The short name H.A.R.D. Protocol 0.2 stays the same. The homepage and guide introduce this question in ordinary language.

The six gates, fifteen criteria, risk depth, formulas and evidence boundaries are unchanged. This is a naming revision, not a new evaluation method or validation result. New packages and runs use a new exact compatibility set. The first 0.2 preview, its tools and all earlier website downloads remain byte-frozen. Old runs are never automatically relabeled. C30 maps this revision to preservation, version and decision-parity checks.

The optional Jev companion is repackaged as 0.1.0-preview.2 to record the new compatibility set. Its rubric and advisory-only boundary are unchanged. No live provider evaluation or external pilot is claimed. The historical rc.3 DOI still identifies rc.3 only.

## Why the explanation and navigation changed

The author clarified the project's origin in architectural previsualization and the missing intermediate review layer in finished-looking AI artifacts. The protocol, MCP instructions and Skill now explain a separate structural review aid across experience, workflow, technical evidence and operation. Original revisions and unknowns must be preserved. The aid is not a new gate or a validated intervention; research sessions retain their controlled design.

The overview explains the problem with one constructed booking example and has two hero paths: begin a review or enter the Developer Library. Detailed criteria and installation live in the library instead of being repeated on the main page. Setup options unfold on demand. Old criterion fragments continue to their canonical reference entries. C31 maps this refinement to tests; no usability improvement is claimed as measured.

# HARD Protocol 0.2: Public Preview, September 24, 2026

Human-centered AI Readiness Deployment Protocol. Exact protocol 0.2-preview.1; MCP 0.2.0rc7; Skill/contract 0.2.0-rc.7.

## Why 0.2 changed

Adopted the requested shorter name and a separate Public Preview status. Centralized display metadata across the page, documents, reports, MCP server and Skill. Existing installation commands, tool names, resource URIs, data fields and criterion IDs are preserved. New records carry exact execution versions; earlier records are not migrated automatically. All six rc.4 candidates remain frozen. C29 maps this transition to tests.

This is not a new evaluation method, a finalized release or evidence of deployment readiness. Actual external use and empirical effectiveness remain unestablished. The historical DOI identifies rc.3 only.

# Protocol 0.1-rc.4-candidate.6: September 24, 2026

MCP 0.2.0rc6; ai-ready Skill/contract 0.2.0-rc.6. Candidate.5 remains frozen.

## Why rc.4 changed

Corrected an inaccurate external-standard comparison at the author's request. Removed the origin claim and related references from the current page, protocol, audit, research boundary and Skill materials. The current reading copy of earlier update entries reflects this correction; archived originals remain unchanged. Other citations and all decision rules remain. C28 records this framing correction, not new validation.

# Protocol 0.1-rc.4-candidate.5: September 24, 2026

MCP 0.2.0rc5; ai-ready Skill/contract 0.2.0-rc.5. Candidate.4 remains frozen.

## Why rc.4 changed

Removed em dashes and en dashes from the current writing, including numeric ranges and log separators. Ranges are written with “to”; separators use colons. Added a matching Skill instruction and regression checks. Rules, calculations, citations and source evidence are unchanged. This is a punctuation revision, not new validation. C27 records the change.

# Protocol 0.1-rc.4-candidate.4: September 24, 2026

MCP 0.2.0rc4; ai-ready Skill/contract 0.2.0-rc.4. Candidate.3 and earlier releases remain frozen.

## Why rc.4 changed

The author requested an editorial pass using the actual Academic Humanize v2.0.0 skill. The revised protocol, website, reading guides and tool instructions use more direct explanations and fewer repeated slogans or contrast formulas. The cost overview now states explicitly that gross savings already deduct residual manual work, consistent with the unchanged formulas.

Decision logic, risk thresholds, evidence requirements, criterion IDs, citations and reported values are preserved. C26 maps the revision to integrity checks, including comparison with the frozen candidate.3 implementation. No new practitioner feedback, pilot, validation result or endorsement is claimed. The [editorial review](docs/editorial-review.md) records the method and limits.

# Protocol 0.1-rc.4-candidate.3: September 24, 2026

MCP 0.2.0rc3; ai-ready Skill/contract 0.2.0-rc.3. Earlier candidates and rc.3 remain byte-frozen.

## Why rc.4 changed

The deep audit found that document completeness could still hide stale requirements, disconnected proposed behavior and unspecified authority. Candidate.3 binds tests to requirement/context as well as artifacts; checks proposed-state graphs and nonempty authority; adds context-driven risk floors, affected-person coverage and a recorded human evidence-quality review. Pilot routing/stops are preserved. A worksheet, public audit and claims/governance rules support usable, inspectable application. C19 to C25 map changes to tests.

These deepen the existing requirements-first T&E, Hillel Glazer traceability, SMB baseline/effort and end-user-use themes without publishing other correspondents' identities. Fifteen criteria retain existing IDs. Correspondence and synthetic regression tests are not controlled empirical validation. No pilot, standard status or worldwide impact is claimed.

# Protocol 0.1-rc.4-candidate.2: September 24, 2026

MCP 0.2.0rc2; ai-ready Skill/contract 0.2.0-rc.2. Candidate only; first candidate and rc.3 remain frozen.

## Why rc.4 changed

The deeper revision turns practitioner themes into a usable review experience: connected current-state maps and preparation time (SMB feedback); exact tested revisions, reference material and inspectable form/fit/function chains (Hillel Glazer, attribution approved); early risk routing and separate operational evaluation (requirements-first T&E feedback); actual work/discussion origins and comprehension notes for bounded use (end-user/advisor feedback).

Added four principles, fourteen criteria, Start here, scenarios, one-question MCP/Skill guidance, private reports, human/agent authority checks, simulated/implemented labels, and a separate study-review contract. The public [update log](https://www.takyejun.com/research/ai-readiness/updates) explains the changes and remaining evidence gaps. Change IDs C11 to C18 map details to tests.

Practitioner correspondence informed refinement but is not equivalent to controlled empirical validation. Usability and the <=15-minute target remain untested. No completed external pilot is claimed. Private identities/comments remain withheld; software tests are not effectiveness evidence.

# Protocol 0.1-rc.4-candidate: September 24, 2026

MCP 0.2.0rc1; ai-ready Skill/contract 0.2.0-rc.1. Candidate only. No new DOI, final release or completed external pilot is claimed.

## Why rc.4 changed

- Requirements-first T&E feedback: define testable end-user requirements early; make the decision explicitly about bounded engineering commitment. Keep operational evaluation separate (C01 to C02).
- Risk-scaled evaluation feedback: low/moderate/high deterministically change required evidence and profile depth (C03).
- Hillel Glazer's traceability feedback, attributed with permission: connect requirements, artifacts, executed validation and reference material explaining form, fit and function (C04).
- SMB baseline/adoption feedback: require measurable current-state evidence and an advisor-led QUICK6 with a visible stop; the <=15-minute target remains untested (C05 to C06).
- Net-benefit feedback: subtract review/correction/escalation/rework from gross savings; report evaluation expense separately (C07).
- End-user and voluntary-use feedback: gather bounded actual use and discussion evidence, with an accessible pilot packet; invitations and correspondence do not count as validation or sponsorship (C08).
- Record permissions, exact versions and evidence digests; keep MCP/Skill logic synchronized and rc.3 frozen (C09 to C10).

Private correspondents' names and comments are withheld in public artifacts. A separate private audit maps source emails to these themes. Practitioner correspondence informed refinement but is not equivalent to controlled empirical validation. No effectiveness, adoption, endorsement or system-performance result is claimed.

See evidence/change-manifest.json for affected requirements/files and acceptance tests; docs/migration-rc3-to-rc4.md for breaking API names and record migration. Historical releases below are preserved.

# Skill 0.1.1: September 9, 2026

- Rename the Skill to ai-ready; update install paths and invocation examples.
- Protocol and MCP behavior are unchanged. Earlier tagged releases remain available.

# Agent tools 0.1.0: September 9, 2026

- Add a local stdio MCP server with schema, session calculations, batch diagnostics, protocol resource and preparation prompt.
- Add the portable hcai-readiness skill with evaluator/reference separation and agent provenance.
- Bring the current protocol reference to archived 0.1-rc.3 and link DOI 10.5281/zenodo.22667623.
- Software tests do not establish empirical validity. This companion software was not included in the September 9 Zenodo archive.

# Changelog

## 0.1-rc.2 - 2026-09-08
- Corrected three reproduced workbook boundary defects and added complementary judgment measures.
- Separated evaluator materials from the answer key and documented prior work and contribution limits.
- Added a controlled-comparison plan. No empirical validation added.


## Documentation between rc.1 and rc.2
- Linked the separate public design system, candidate evaluation checks and an actual documentation consistency correction.
- Preserved v0.1-rc.1 PDFs, workbooks and release assets. No external validation or full applied evaluation is claimed.

## 0.1-rc.1 - 2026-09-08
- Packaged the engineering-handoff profile, evaluator scorecard and spreadsheet calculations.
- Added traceable synthetic requirements, recovery, reference, findings and batch records.
- Added a specification-based fictional artifact and a feasibility kit.
- Separated evaluator metrics from artifact gate eligibility and owner approval.
- Recorded missing data, abstentions, reference uncertainty and scope limits.
- Corrected the NIST relationship: a separate comment was transmitted September 6; the protocol is not represented as an attachment, adoption or endorsement.

This is a release candidate for author review. External review, empirical validation and archival publication are not completed by creating these files.
