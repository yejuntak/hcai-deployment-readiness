"""Build separately versioned candidate PDFs from canonical Markdown."""
import html
import re
import sys
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether, PageBreak

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from hcai_readiness.versions import public_title, RELEASE_LABEL, PROTOCOL_VERSION, DISTRIBUTION_ID, MCP_VERSION, SKILL_VERSION

OUTPUT = ROOT / "output/pdf"
INK = colors.HexColor("#172b43")
BLUE = colors.HexColor("#244cac")
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="BodyCandidate", fontName="Helvetica", fontSize=11, leading=15.5,
                         spaceAfter=8, textColor=INK, alignment=TA_LEFT, allowWidows=0, allowOrphans=0))
styles.add(ParagraphStyle(name="CellCandidate", fontName="Helvetica", fontSize=10, leading=13,
                         spaceAfter=0, textColor=INK))
styles.add(ParagraphStyle(name="TitleCandidate", fontName="Helvetica-Bold", fontSize=23, leading=28,
                         spaceAfter=16, textColor=INK, keepWithNext=True))
styles.add(ParagraphStyle(name="HeadingCandidate", fontName="Helvetica-Bold", fontSize=13, leading=17,
                         spaceBefore=12, spaceAfter=7, textColor=BLUE, keepWithNext=True))


def inline(text):
    text = text.replace("\u2014", "-").replace("\u2013", "-").replace("→", " -> ").replace("−", "-").replace("≤", "<=")
    text = html.escape(text)
    def link(match):
        label, target = match.groups()
        if not target.startswith(('https://', 'http://')):
            name = target.rsplit('/', 1)[-1].replace('.md', '.html')
            target = 'https://www.takyejun.com/static/research/ai-readiness/' + DISTRIBUTION_ID + '/' + name
        return '<link href="' + target + '" color="#244cac"><u>' + label + '</u></link>'
    text = re.sub(r"\[([^]]+)\]\(([^)]+)\)", link, text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", text)
    return text.replace("`", "").replace("\n", "<br/>")


def footer(canvas, doc):
    canvas.setStrokeColor(colors.HexColor("#d6dce2"))
    canvas.line(44, 39, 568, 39)
    canvas.setFillColor(colors.HexColor("#506179"))
    canvas.setFont("Helvetica", 8)
    canvas.drawString(44, 26, f"{public_title()} | {RELEASE_LABEL} | {PROTOCOL_VERSION} | Scope applies; no deployment approval")
    canvas.drawString(44, 15, f"MCP {MCP_VERSION} | Skill/contract {SKILL_VERSION}")
    canvas.drawRightString(568, 26, str(doc.page))


def build(source, destination):
    lines = source.read_text().splitlines()
    body_style = styles["BodyCandidate"]
    if source.name == "hard-0.2-preview-3-external-packet.md":
        body_style = ParagraphStyle(name="PacketBody", parent=body_style, fontSize=10.5, leading=12.2, spaceAfter=2)
    story = []
    i = 0
    while i < len(lines):
        line = lines[i]
        # Exact execution identifiers are repeated in the footer, not on an orphan final page.
        if line.startswith("Execution versions:"):
            i += 1
            continue
        if not line.strip():
            i += 1
            continue
        if line.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [x.strip() for x in lines[i].strip("|").split("|")]
                if not all(re.fullmatch(r"[: -]+", c) for c in cells):
                    rows.append([Paragraph(inline(c).replace("PROCEED_TO_ENGINEERING", "PROCEED_TO_<br/>ENGINEERING").replace("INSUFFICIENT_EVIDENCE", "INSUFFICIENT_<br/>EVIDENCE"), styles["CellCandidate"]) for c in cells])
                i += 1
            n = len(rows[0])
            widths = [524 / n] * n
            if n == 3:
                widths = [130, 184, 210] if rows[0][0].getPlainText() == 'Result' else [190, 214, 120]
            if n == 4:
                widths = [128, 132, 132, 132]
            table = Table(rows, colWidths=widths, repeatRows=1, hAlign="LEFT")
            table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e7edf7")),
                                       ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#d6dce2")),
                                       ("VALIGN", (0, 0), (-1, -1), "TOP"),
                                       ("LEFTPADDING", (0, 0), (-1, -1), 7),
                                       ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                                       ("TOPPADDING", (0, 0), (-1, -1), 7),
                                       ("BOTTOMPADDING", (0, 0), (-1, -1), 7)]))
            if len(story) >= 2 and isinstance(story[-2], Paragraph) and story[-2].style.name == "HeadingCandidate":
                paragraph, heading = story.pop(), story.pop()
                story.extend([heading, paragraph, table, Spacer(1, 9)])
            else:
                story.extend([table, Spacer(1, 9)])
            continue
        if line.startswith("# "):
            story.append(Paragraph(inline(line[2:]), styles["TitleCandidate"]))
        elif line.startswith("##"):
            story.append(Paragraph(inline(line.lstrip("# ")), styles["HeadingCandidate"]))
        else:
            text = line
            while i + 1 < len(lines) and lines[i + 1].strip() and not lines[i + 1].startswith(("#", "|", "- ")):
                if re.match(r"\d+\. ", lines[i + 1]):
                    break
                i += 1
                text += ("\n" if text.endswith("  ") else " ") + lines[i]
            story.append(Paragraph(inline(text), body_style))
        i += 1
    SimpleDocTemplate(str(destination), pagesize=letter, leftMargin=44, rightMargin=44,
                      topMargin=32 if source.name.endswith("external-packet.md") else 43, bottomMargin=53, title=public_title() + " | " + RELEASE_LABEL + " | " + source.stem,
                      author="Yejun Tak").build(story, onFirstPage=footer, onLaterPages=footer)


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    docs = {
        "protocol/0.2-preview.3/PROTOCOL.md": "HARD-Protocol-0.2-preview.3.pdf",
        "protocol/0.2-preview.3/ARTIFACT-REVIEW.md": "HARD-Artifact-Review-0.2-preview.3.pdf",
        "protocol/0.2-preview.3/QUICK-6.md": "HARD-QUICK-6-0.2-preview.3.pdf",
        "protocol/0.2-preview.3/FULL-PROFILE.md": "HARD-Full-Profile-0.2-preview.3.pdf",
        "Pilot-Kit/hard-0.2-preview-3-external-packet.md": "HARD-External-Pilot-Packet-0.2-preview.3.pdf",
    }
    for source, name in docs.items():
        build(ROOT / source, OUTPUT / name)
        print(name)


if __name__ == "__main__":
    main()
