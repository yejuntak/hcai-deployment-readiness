# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Yejun Tak
"""Deterministic questions and decision cards for a guided review. These do not generate evidence."""
import json
from importlib.resources import files
from .contracts import Assessment
from .engine import assess, RISK_FIELDS, CONTEXT_FLOORS
from .versions import versions

GUIDES = {
    "G1_BASELINE": {
        "title": "Understand today's work", "question": "Can you show one recent case from its first step to its final outcome?",
        "owner": "workflow owner", "fields": ["scope.unit_of_work", "baseline.steps", "baseline.entry_step_id", "baseline.observation_window", "baseline.sample_size", "baseline.labor_minutes_per_case", "baseline.cycle_minutes_per_case", "baseline.volume_per_period", "baseline.period", "baseline.map_review"],
        "action": "Observe a current case. Map who does each step and handles exceptions. Record labor without overlapping categories, and record elapsed time separately.",
        "example": "Illustration only: intake received -> advisor review -> confirmed; missing details -> correction -> return to review.",
        "do_not": "Do not replace observations with the proposed process or recollected savings estimates."},
    "G2_NEED_REQUIREMENTS": {
        "title": "Name the need and success condition", "question": "Whose difficulty are we solving, and what observable result would satisfy them?",
        "owner": "product/workflow owner", "fields": ["artifact_population", "scope", "workflow.outcome", "workflow.needs", "workflow.requirements", "choice_ledger"],
        "action": "Classify the artifact population. Use work records or an end-user discussion to define success and its owner. Inspect consequential choices in the artifact against that purpose and explicit criteria. For every important choice, explicitly decide whether engineering deepening applies and record why. Separate recorded historical alternatives from alternatives proposed in this review. Include affected non-users and review access, privacy/security, unequal effects and human control. Compare a non-AI option.",
        "example": "Illustration only: after cancellation, the advisor can reopen all previously entered contact fields.",
        "do_not": "Do not count two copies of one source, general industry articles, or feedback about this protocol as independent customer need evidence. Do not present a reconstruction of AI reasoning as a historical record."},
    "G3_STATES_RECOVERY": {
        "title": "Model system truth, state and recovery", "question": "What must remain true as this workflow changes state, and what happens when that model is wrong or incomplete?",
        "owner": "workflow designer and operator", "fields": ["workflow.states", "workflow.state_review", "workflow.dependencies", "workflow.dependency_review", "workflow.action_boundaries", "workflow.human_control_review"],
        "action": "Walk normal, edge and recovery paths. For choices that require engineering deepening, externalize the relevant source of truth, ownership, state, boundary, contract, failure and time/ordering surfaces, plus the consequential assumptions the choice depends on. Record only what supplied evidence supports. Challenge repeated, concurrent, partial and dependency-failure behavior when consequence makes it material.",
        "example": "Illustration only: a missing field is shown to the advisor; cancelling returns to saved intake without data loss.",
        "do_not": "Do not infer an error path, source of truth or architecture from a polished result. Do not turn a newly generated explanation into historical rationale."},
    "G4_TRACEABILITY": {
        "title": "Check the requirement and tested revision", "question": "Show the requirement, the exact artifact revision and the check that tested it together.",
        "owner": "requirement owner and reviewer", "fields": ["workflow.important_artifact_ids", "workflow.requirements", "workflow.validations", "choice_ledger", "evidence"],
        "action": "Check each requirement -> artifact -> executed-check link and the evidence verifying its consequential choices. When engineering deepening applies, execute or inspect the bounded challenge scenarios rather than treating plausible reasoning as proof. Compare artifact and requirement/context fingerprints. After a choice, decision surface, challenge condition, requirement or artifact changes, repeat the affected check; replacing the hash does not establish a new pass.",
        "example": "Illustration only: requirement R1 -> saved-intake screen revision 2 -> recorded cancellation walkthrough of that exact file.",
        "do_not": "Do not count a planned test, an old artifact revision, or visual fidelity as a passing check."},
    "G5_OVERSIGHT": {
        "title": "Estimate the remaining human work", "question": "For each case, how much human checking, correction and remaining manual work will be needed?",
        "owner": "operating workflow owner", "fields": ["operational_oversight", "costs"],
        "action": "Estimate review, correction, escalation, rework and residual manual minutes separately, with a basis. Keep recurring and one-time costs separate.",
        "example": "Illustration only: 15 gross minutes saved minus 15 oversight minutes leaves zero net time savings.",
        "do_not": "Do not count the same minute twice or convert unknown money, time or token usage into zero."},
    "G6_COMMITMENT": {
        "title": "Bound the engineering decision", "question": "Which engineering step does this evidence support, how much may it use, and when should it be reviewed again?",
        "owner": "engineering decision owner", "fields": ["handoff", "evaluator_burden", "choice_ledger"],
        "action": "Resolve blocking findings and consequential choices and complete the reviews required for this risk tier. Retain the current choice when an accountable human review supplies adequate justification and verification; missing historical rationale alone does not require replacement. For software work, make the next commitment the smallest coherent slice that can expose an important assumption end to end, not a broad layer-by-layer build. Record preparation and session effort, then name the scope, owner, resource cap and revisit trigger.",
        "example": "Illustration only: one engineer-day to prove one invitation lifecycle from authorized creation through persistence, duplicate/revoked handling and an observable outcome; no broader dashboard build.",
        "do_not": "Do not treat this recommendation as owner authorization or deployment approval. Explain funding despite nonpositive benefit."},
}

LABELS = {"PROCEED_TO_ENGINEERING": "Evidence supports a bounded engineering step",
          "REVISE": "Revise before committing engineering resources",
          "INSUFFICIENT_EVIDENCE": "More evidence is needed before an engineering decision"}


def criteria_catalog():
    return json.loads(files("hcai_readiness").joinpath("criteria.json").read_text())


def criterion_guide(criterion_id):
    match = next((c for c in criteria_catalog()["criteria"] if c["id"] == criterion_id), None)
    if match is None:
        return {"found": False, "valid_ids": [c["id"] for c in criteria_catalog()["criteria"]]}
    return {"found": True, "versions": versions(), **match, "gate_guide": GUIDES[match["gate"]],
            "claim_limit": "This candidate criterion requires human evidence review as well as structural checks. Neither establishes system performance."}


def new_review(run_id, recorded_at, evaluator_kind, requested_profile="QUICK6", artifact_population="unknown"):
    """Only user-supplied metadata and declared versions are populated; all evidence is empty."""
    return Assessment(run_id=run_id, recorded_at=recorded_at, evaluator_kind=evaluator_kind,
                      requested_profile=requested_profile, artifact_population=artifact_population,
                      versions=versions(), evidence=[]).model_dump()


def next_step(a, result=None):
    r = result or assess(a)
    if not a.scope.workflow_name or not a.scope.unit_of_work:
        return {"stage": "SCOPE", "question": "Which one piece of work are we reviewing, and what counts as one completed case?",
                "owner": "workflow owner", "fields": ["scope.workflow_name", "scope.unit_of_work", "scope.starts_when", "scope.ends_when"],
                "action": "Name the workflow and its boundaries before discussing the proposed technology."}
    if r["routing"]["status"] == "USE_FULL":
        unknown = ["risk." + k for k in RISK_FIELDS if getattr(a.risk, k) is None]
        unknown += ['risk.context.'+k for k in CONTEXT_FLOORS if getattr(a.risk.context,k) is None]
        return {"stage": "PROFILE_ROUTING", "question": "Who will help classify the missing risk information and lead the full review?" if unknown else "Who will lead the full review for this workflow?",
                "owner": "workflow owner and qualified reviewer", "fields": unknown or ["requested_profile"],
                "action": r["routing"]["reason"] + " Preserve this record; create a new FULL run linked through previous_run_id and revision_summary."}
    gate = next((g for g in r["gates"] if g["status"] != "PASS"), None)
    if gate:
        return {"stage": gate["id"], **GUIDES[gate["id"]], "reasons": gate["reasons"],
                "resume_rule": "Preserve a stopped QUICK6 run. After remediation, use a new FULL run with a previous-run link."}
    return {"stage": "OWNER_DECISION", "question": "Does the named owner authorize this exact bounded engineering step?",
            "owner": a.handoff.decision_owner_role, "fields": [],
            "action": "Record the owner's separate dated authorization or refusal and conditions. Do not infer authorization from a gate pass."}


def decision_card(a, result=None):
    r = result or assess(a)
    return {"headline": LABELS[r["decision"]], "decision": r["decision"], "run_id": a.run_id,
            "mode": a.mode, "artifact_population": a.artifact_population,
            "versions": versions(), "workflow": a.scope.workflow_name, "unit_of_work": a.scope.unit_of_work,
            "risk": r["risk_tier"], "required_profile": r["required_profile"], "routing": r["routing"],
            "stop_at": r["stop_at_gate"], "next_step": next_step(a, r), "attention_items": r["attention_items"], "assurance": r['assurance'],
            "gates": [{**g, "title": GUIDES[g["id"]]["title"],
                       "criteria_ids": [c["id"] for c in criteria_catalog()["criteria"] if c["gate"] == g["id"]]} for g in r["gates"]],
            "operating_benefit": r["roi"], "protocol_evaluation_burden": r["evaluator_burden"],
            "operating_oversight": r["operational_oversight"], "operational_performance": r["operational_performance"],
            "choice_review": r["choice_review"],
            "engineering_scope": a.handoff.commitment_scope, "resource_limit": a.handoff.resource_limit,
            "owner": a.handoff.decision_owner_role, "revisit_when": a.handoff.next_review_trigger,
            "boundary": "Engineering recommendation only. Owner authorization and deployment evaluation are separate.",
            "input_sha256": r["provenance"]["input_sha256"], "record_privacy": "PRIVATE working record. Check permissions and identifying content before sharing."}


def guided_review(a, include_assessment=False):
    r = assess(a)
    output = {"decision_card": decision_card(a, r)}
    if include_assessment:
        output["assessment"] = r
    return output
